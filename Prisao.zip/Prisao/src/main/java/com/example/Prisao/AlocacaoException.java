package com.example.Prisao;

public class AlocacaoException extends Exception {
    public AlocacaoException(String message) {
        super(message);
    }
}

package com.example.Prisao;

public enum Periculosidade {
    CRÍTICA, ALTA, MEDIA, BAIXA;


}

